import 'package:flutter/services.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

part 'native_channels.g.dart';

class NativeChannels {
  static const MethodChannel _channel = MethodChannel('com.example.netwatch/native');

  Future<String> getArpTable() async {
    try {
      final String result = await _channel.invokeMethod('getArpTable');
      return result;
    } on PlatformException catch (_) {
      return "";
    }
  }

  Future<Map<dynamic, dynamic>> getTrafficStats({int? uid}) async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>('getTrafficStats', {'uid': uid});
      return result ?? {'rx': 0, 'tx': 0};
    } catch (_) {
      return {'rx': 0, 'tx': 0};
    }
  }

  Future<List<Map<dynamic, dynamic>>> getUsageStats() async {
    try {
      final result = await _channel.invokeListMethod<Map<dynamic, dynamic>>('getUsageStats');
      return result ?? [];
    } catch (_) {
      return [];
    }
  }

  Future<List<Map<dynamic, dynamic>>> getNetworkInterfaces() async {
    try {
      final result = await _channel.invokeListMethod<Map<dynamic, dynamic>>('getNetworkInterfaces');
      return result ?? [];
    } catch (_) {
      return [];
    }
  }

  Future<bool> acquireMulticastLock() async {
    try {
      final result = await _channel.invokeMethod<bool>('acquireMulticastLock');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> releaseMulticastLock() async {
    try {
      final result = await _channel.invokeMethod<bool>('releaseMulticastLock');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<Map<dynamic, dynamic>> getWifiInfo() async {
    try {
      final result = await _channel.invokeMapMethod<dynamic, dynamic>('getWifiInfo');
      return result ?? {};
    } catch (_) {
      return {};
    }
  }

  /// Returns {'model': String, 'ip': String} from the native layer.
  Future<Map<dynamic, dynamic>> getDeviceInfo() async {
    try {
      final result = await _channel.invokeMapMethod<dynamic, dynamic>('getDeviceInfo');
      return result ?? {};
    } catch (_) {
      return {};
    }
  }
}

@Riverpod(keepAlive: true)
NativeChannels nativeChannels(NativeChannelsRef ref) {
  return NativeChannels();
}
