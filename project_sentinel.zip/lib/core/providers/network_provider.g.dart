// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'network_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$wifiSsidHash() => r'0cbffd544b62dc7cd09cac8d857068cbc5c1cdfb';

/// See also [wifiSsid].
@ProviderFor(wifiSsid)
final wifiSsidProvider = AutoDisposeFutureProvider<String>.internal(
  wifiSsid,
  name: r'wifiSsidProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$wifiSsidHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef WifiSsidRef = AutoDisposeFutureProviderRef<String>;
String _$networkDevicesHash() => r'd4da2e0a344992c0eb3067a86cd9c8b637360b4f';

/// See also [networkDevices].
@ProviderFor(networkDevices)
final networkDevicesProvider =
    AutoDisposeFutureProvider<List<NetworkDevice>>.internal(
      networkDevices,
      name: r'networkDevicesProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$networkDevicesHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef NetworkDevicesRef = AutoDisposeFutureProviderRef<List<NetworkDevice>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
