import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../discovery/arp_service.dart';
import '../../discovery/mdns_service.dart';
import '../../discovery/mac_vendor_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../native/native_channels.dart';

part 'network_provider.g.dart';

class NetworkDevice {
  final String ip;
  final String mac;
  final String vendor;
  final String mdnsName;
  final String status;
  final IconData icon;

  NetworkDevice({
    required this.ip,
    required this.mac,
    required this.vendor,
    required this.mdnsName,
    required this.status,
    required this.icon,
  });

  String get displayName {
    if (mdnsName.isNotEmpty) return mdnsName;
    if (vendor.isNotEmpty) return '$vendor Device';
    return 'Unknown Device';
  }

  String get displayOs {
    if (mdnsName.toLowerCase().contains('apple') || mdnsName.toLowerCase().contains('macbook') || mdnsName.toLowerCase().contains('iphone')) {
      return 'Apple OS';
    }
    return '';
  }
}

@riverpod
Future<String> wifiSsid(WifiSsidRef ref) async {
  final native = ref.read(nativeChannelsProvider);
  final info = await native.getWifiInfo();
  debugPrint('[WIFI] Raw getWifiInfo result: $info');
  var ssid = info['ssid']?.toString().replaceAll('"', '') ?? '';
  // Strip Android placeholder values
  if (ssid == '<unknown ssid>' || ssid == '0x' || ssid.isEmpty) {
    ssid = '';
  }
  debugPrint('[WIFI] Parsed SSID: "$ssid"');
  return ssid.isEmpty ? 'Unknown Network' : ssid;
}

@riverpod
Future<List<NetworkDevice>> networkDevices(NetworkDevicesRef ref) async {
  final arpEntries = await ref.watch(arpTableProvider.future);
  final mdnsRecords = ref.watch(mdnsScannerProvider);

  final List<NetworkDevice> devices = [];

  // ensure db is loaded
  await ref.read(macVendorServiceProvider.future);
  final macVendorProvider = ref.read(macVendorServiceProvider.notifier);

  for (final entry in arpEntries) {
    // Attempt to lookup MAC Vendor
    final vendor = macVendorProvider.getVendor(entry.mac);
    
    // Check mDNS corresponding to IP
    String hostname = '';
    mdnsRecords.whenData((records) {
      // Find hostname whose addresses include this IP, simplified logic
      for (final rec in records) {
        if (rec.ip == entry.ip) {
          hostname = rec.hostname;
          break;
        }
      }
    });

    IconData icon = Icons.device_unknown;
    if (vendor.toLowerCase().contains('apple') || hostname.toLowerCase().contains('mac') || hostname.toLowerCase().contains('iphone')) {
      icon = Icons.smartphone; // Rough assumption
    } else if (vendor.toLowerCase().contains('samsung') || hostname.toLowerCase().contains('tv')) {
      icon = Icons.tv;
    } else if (entry.ip.endsWith('.1')) {
      icon = Icons.router;
    } else if (vendor.isNotEmpty) {
      icon = Icons.laptop;
    }

    devices.add(NetworkDevice(
      ip: entry.ip,
      mac: entry.mac,
      vendor: vendor,
      mdnsName: hostname,
      status: entry.isReachable ? 'active' : 'idle',
      icon: icon,
    ));
  }

  // Include any mDNS devices that weren't in the ARP table (common on Android 10+)
  mdnsRecords.whenData((records) {
    for (final rec in records) {
      if (!devices.any((d) => d.ip == rec.ip)) {
        devices.add(NetworkDevice(
          ip: rec.ip,
          mac: 'Unknown',
          vendor: macVendorProvider.getVendor('Unknown'),
          mdnsName: rec.hostname,
          status: 'active',
          icon: rec.hostname.toLowerCase().contains('apple') || rec.hostname.toLowerCase().contains('mac') || rec.hostname.toLowerCase().contains('iphone') ? Icons.smartphone : Icons.device_unknown,
        ));
      }
    }
  });

  return devices;
}
