import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';
import 'ui/theme.dart';
import 'ui/app_layout.dart';
import 'discovery/mdns_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Request all needed permissions upfront, BEFORE running the app.
  // This ensures location is granted before any WiFi/ARP calls happen.
  await [
    Permission.locationWhenInUse,
    Permission.location,
    Permission.notification,
    Permission.nearbyWifiDevices,
  ].request();

  runApp(
    const ProviderScope(
      child: NetwatchApp(),
    ),
  );
}

class NetwatchApp extends StatelessWidget {
  const NetwatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Netwatch',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      debugShowCheckedModeBanner: false,
      home: const _AppBootstrap(),
    );
  }
}

/// Sits INSIDE MaterialApp so it has MaterialLocalizations.
/// Triggers the initial mDNS scan and Usage Access prompt.
class _AppBootstrap extends ConsumerStatefulWidget {
  const _AppBootstrap();

  @override
  ConsumerState<_AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends ConsumerState<_AppBootstrap> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Trigger initial mDNS scan so devices appear automatically
      ref.read(mdnsScannerProvider.notifier).scan();
      _promptUsageAccessIfNeeded();
    });
  }

  Future<void> _promptUsageAccessIfNeeded() async {
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Enable Usage Access'),
        content: const Text(
          'NetWatch needs "Usage Access" permission to show which apps '
          'are using mobile/Wi-Fi data.\n\n'
          'Tap "Open Settings", find NetWatch in the list, and enable it.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Later'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings(); // From permission_handler, opens app-level settings
            },
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const AppLayout();
  }
}
