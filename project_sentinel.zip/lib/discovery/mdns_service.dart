import 'package:multicast_dns/multicast_dns.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../core/native/native_channels.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

part 'mdns_service.g.dart';

class MdnsDevice {
  final String hostname;
  final String ip;
  final List<String> services;

  MdnsDevice(this.hostname, this.ip, this.services);
}

@riverpod
class MdnsScanner extends _$MdnsScanner {
  @override
  Future<List<MdnsDevice>> build() async => [];

  Future<void> scan() async {
    final native = ref.read(nativeChannelsProvider);
    state = const AsyncValue.loading();

    // Must acquire Multicast lock on Android
    await native.acquireMulticastLock();

    final MDnsClient client = MDnsClient();
    await client.start();

    // Query for popular services
    final serviceTypes = [
      '_googlecast._tcp.local', 
      '_airplay._tcp.local', 
      '_spotify-connect._tcp.local',
      '_http._tcp.local',
      '_smb._tcp.local'
    ];

    final devices = <String, MdnsDevice>{};

    for (final svc in serviceTypes) {
      await for (final PtrResourceRecord ptr in client.lookup<PtrResourceRecord>(
          ResourceRecordQuery.serverPointer(svc))) {
        
        await for (final SrvResourceRecord srv in client.lookup<SrvResourceRecord>(
            ResourceRecordQuery.service(ptr.domainName))) {
          
          await for (final IPAddressResourceRecord ipRecord in client.lookup<IPAddressResourceRecord>(
              ResourceRecordQuery.addressIPv4(srv.target))) {
            
            final ip = ipRecord.address.address;
            if (devices.containsKey(ip)) {
                if (!devices[ip]!.services.contains(svc)) {
                    devices[ip]!.services.add(svc);
                }
            } else {
                devices[ip] = MdnsDevice(srv.target, ip, [svc]);
            }
          }
        }
      }
    }

    client.stop();
    await native.releaseMulticastLock();
    state = AsyncValue.data(devices.values.toList());
  }
}
