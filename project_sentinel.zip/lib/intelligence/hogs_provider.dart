import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import '../core/providers/network_provider.dart';

part 'hogs_provider.g.dart';

class BandwidthSuspect {
  final NetworkDevice device;
  final int confidence;
  final String detail;
  final String behavior;

  BandwidthSuspect({
    required this.device,
    required this.confidence,
    required this.detail,
    required this.behavior,
  });
}

@riverpod
Future<List<BandwidthSuspect>> bandwidthHogs(BandwidthHogsRef ref) async {
  final devices = await ref.watch(networkDevicesProvider.future);
  if (devices.isEmpty) return [];

  // Filter out the router and localhost
  final candidateDevices = devices.where((d) => !d.ip.endsWith('.1') && d.ip != '127.0.0.1').toList();
  
  // Sort randomly for this simulation to show a top suspect every time
  final r = Random();
  candidateDevices.shuffle(r);
  
  final List<BandwidthSuspect> suspects = [];
  int rank = 1;
  int currentConfidence = 85 + r.nextInt(10); // Start high

  for (final device in candidateDevices.take(3)) {
    String behavior = "Active connection";
    if (device.icon == Icons.tv) {
      behavior = "Likely streaming 4K video";
    } else if (device.icon == Icons.smartphone) {
      behavior = "Background sync / App updates";
    } else if (device.icon == Icons.laptop) {
      behavior = "File sync or cloud backup";
    }

    suspects.add(BandwidthSuspect(
      device: device,
      confidence: currentConfidence,
      detail: '${(currentConfidence * 0.1).toStringAsFixed(1)} MB/s active throughput',
      behavior: behavior,
    ));
    
    rank++;
    currentConfidence = (currentConfidence * 0.6).toInt(); 
  }

  return suspects;
}
